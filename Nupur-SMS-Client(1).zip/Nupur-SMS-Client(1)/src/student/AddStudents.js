import React, { Component } from 'react';
import { FaPlus } from 'react-icons/fa';
import { createStudent } from '../util/APIUtils';
import { Form, Input, Button, Icon,Select, Col, notification } from 'antd';
import { sessions } from "../variables/Variables.jsx";
const Option = Select.Option;

class AddStudents extends Component {

  

    constructor() {
        super();
        this.state = {
          myStudents: [],
          firstName: '',
          lastName: '',
          studentEmail: '',
          parentEmail: '',
          doa: '',
          academicSession:"2019-2020"
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleAdd = this.handleAdd.bind(this);
      }


      handleAdd(e) {
        e.preventDefault();
        let studentData = {
            firstName: this.state.firstName,
            lastName: this.state.lastName,
            studentEmail: this.state.studentEmail,
            parentEmail: this.state.parentEmail,
            doa: this.state.doa ,
            academicSession:this.state.academicSession
        };

        createStudent(studentData)
        .then(response => {
          notification.success({
            message: 'Polling App',
            description: "Student Successfully Added",
        });          
        this.props.history.push("/student/new");
      }).catch(error => {
          if(error.status === 401) {
              this.props.handleLogout('/login', 'error', 'You have been logged out. Please login create student.');    
          } else {
              notification.error({
                  message: 'Polling App',
                  description: error.message || 'Sorry! Something went wrong. Please try again!'
              });              
          }
      });

    this.setState({
        firstName: '',
        lastName: '',
        studentEmail: '',
        parentEmail: '',
        doa: '',
        academicSession:''
    });
    this.props.toggleForm();
  }


  handleChange(e) {
    const target = e.target;
    const value = target.value;
    const name = target.name;

    this.setState({
      [name]: value
    });
  }

  handleSessionChange(value) {
    const academicSession = Object.assign(this.state.academicSession, {session: value});
    this.setState({
      academicSession: academicSession
    });
}


  render() {
    return (
      <div
        className={
          'card textcenter mt-3 ' +
          (this.props.formDisplay ? '' : 'add-appointment')
        }
      >
        <div
          className="apt-addheading card-header bg-primary text-white"
          onClick={this.props.toggleForm}
        >
          <FaPlus /> Add Student
        </div>

        <div className="card-body">
          <form id="aptForm" noValidate onSubmit={this.handleAdd}>
            <div className="form-group form-row">
              <label
                className="col-md-2 col-form-label text-md-right"
                htmlFor="firstName"
                readOnly
              >
                First Name
              </label>
              <div className="col-md-10">
                <input
                  type="text"
                  className="form-control"
                  name="firstName"
                  placeholder="First Name"
                  value={this.state.firstName}
                  onChange={this.handleChange}
                />
              </div>
            </div>

            <div className="form-group form-row">
              <label
                className="col-md-2 col-form-label text-md-right"
                htmlFor="lastName"
              >
                Last Name
              </label>
              <div className="col-md-10">
                <input
                  type="text"
                  className="form-control"
                  name="lastName"
                  placeholder="Last Name"
                  value={this.state.lastName}
                  onChange={this.handleChange}
                />
              </div>
            </div>
            <div className="form-group form-row">
              <label
                className="col-md-2 col-form-label text-md-right"
                htmlFor="studentEmail"
              >
                Student Email
              </label>
              <div className="col-md-10">
                <input
                  type="email"
                  className="form-control"
                  name="studentEmail"
                  placeholder="Student Email"
                  value={this.state.studentEmail}
                  onChange={this.handleChange}
                />
              </div>
            </div>
            <div className="form-group form-row">
              <label
                className="col-md-2 col-form-label text-md-right"
                htmlFor="studentEmail"
              >
                Parent's Email
              </label>
              <div className="col-md-10">
                <input
                  type="email"
                  className="form-control"
                  name="parentEmail"
                  placeholder="Parent Email"
                  value={this.state.parenttEmail}
                  onChange={this.handleChange}
                />
              </div>
            </div>


            <div className="form-group form-row">
              <label
                className="col-md-2 col-form-label text-md-right"
                htmlFor="aptDate"
              >
                Date
              </label>
              <div className="col-md-4">
                <input
                  type="date"
                  className="form-control"
                  name="doa"
                  id="doa"
                  value={this.state.doa}
                  onChange={this.handleChange}
                />
              </div>
              <label
                className="col-md-2 col-form-label text-md-right"
                htmlFor="aptDate"
              >
                Session
              </label>
              <div className="col-md-4">
              <Select 
                                        name="session"
                                        defaultValue="2019-2020" 
                                        onChange={this.handlePollDaysChange}
                                        value={this.state.academicSession}
                                        style={{ width: 60 }} >
                                       {
                                            Array.from(sessions.keys()).map(i => 
                                                <Option key={i}>{i+2019}</Option>                                        
                                            )
                                        }
                                    </Select>                 
                                    
              </div>
              
            </div>

            <div className="form-group form-row mb-0">
              <div className="offset-md-2 col-md-10">
                <button
                  type="submit"
                  className="btn btn-primary d-block ml-auto"
                >
                  Add Student
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    );
  }
}

export default AddStudents;
