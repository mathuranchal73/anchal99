import React, { Component } from 'react';
import { FaTimes } from 'react-icons/fa';
import Moment from 'react-moment';
import { Grid, Row, Col, Table } from "react-bootstrap";
import { thArray } from "../variables/Variables.jsx";
import Card from "../components/Card/Card.jsx";
import { getAllStudents } from '../util/APIUtils';
import { Button } from 'antd';

class ListStudents extends Component {

  
    render() {
        return (
          <div >
             <div className="content">
            <Grid fluid>
              <Row>
                <Col md={12}>
                  <Card
                    title="Student Records"
                    category="Total Records:"
                    ctTableFullWidth
                    ctTableResponsive
                    content={
                      <Table striped hover>
                        <thead>
                          <tr>
                            {thArray.map((prop, key) => {
                              return <th key={key}>{prop}</th>;
                            })}
                          </tr>
                        </thead>
                        <tbody>
                        <th >
                        {this.props.students.map(item => {
                          return <tr>{item.registrationNo}</tr>;      
                        })}
                        </th>
                        <th >
                        {this.props.students.map(item => {
                          return <tr>{item.firstName} {item.lastName}</tr>;      
                        })}
                        </th>
                        <th >
                        {this.props.students.map(item => {
                          return <tr>{item.doa}</tr>;      
                        })}
                        </th>
                        <th >
                        {this.props.students.map(item => {
                          return <tr>{item.rollNo}</tr>;      
                        })}
                        </th>
                        <th >
                        {this.props.students.map(item => {
                          return <tr>{item.academicSessions}</tr>;      
                        })}
                        </th>
                        <th >
                        {this.props.students.map(item => {
                          return <tr>{item.studentEmail}</tr>;      
                        })}
                        </th>
                        <th>
                        {this.props.students.map(item => {
                        return <tr><Button type="submit" className="btn btn-primary d-block ml-auto">Edit</Button></tr>;      
                        })}  
                        </th>
                        </tbody>
                      </Table>
                      }
                      />
                    </Col>
                      </Row>
                      </Grid>
                      </div>      
                     
                    
    
                  
                  
                 
                </div>
              
        );
      }
    }
    
    export default ListStudents;
    