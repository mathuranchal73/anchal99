import { editStudent } from '../util/APIUtils';

import React, { Component } from 'react';
import './Student.css';
import { getStudentByID } from '../util/APIUtils';

class EditStudent extends Component {

    constructor(props){  
        super(props);  
        this.state = {
            studentData: [],
          id:''
        }
    
        this.loadStudentDetails = this.loadStudentDetails.bind(this);
        } 
        

        loadStudentDetails(){
            let promise;
            promise = getStudentByID(this.props.id); 

            
        }
        


  render() {
    return (  
        <div className='popup'>  
        <div className='popup\_inner'>  
        <h1>{this.props.text}</h1>  
        <button onClick={this.props.closePopup}>close me</button>  

        <div className="content">
			<div className="container-fluid">
				<div className="row">
                    <div className="col-md-8">
                         <div className="card">
                            <div className="card-header">
                                <h4 className="card-title">Edit Student Record</h4>
                            </div>
                            <div className="card-body">
                                <form>
                                    <div className="row">

                                    <div className="col-md-5 pr-1">
                                    <div className="form-group">
                                        <label>Registration Number (disabled)</label>
                                        <input type="text" className="form-control" placeholder="Registration Number" value={this.props.promise.registrationNo}/>
                                    </div>                                                          
                                    </div>
                                                                                                
                                    <div className="col-md-3 px-1">
                                    <div className="form-group">
                                        <label>Firstname</label>
                                        <input type="text" className="form-control" placeholder="FirstName" value="ÄBC" onBlur={this.validateUsernameAvailability}
																											onChange={(event) => this.handleInputChange(event, this.validateUsername)}/>
                                    </div>
                                    </div>
                                                                                               
                                     <div className="col-md-4 pl-1">
                                     <div className="form-group">
                                        <label for="LastName">Last Name</label>
                                        <input type="text" className="form-control" placeholder="LastName" value="ÄBC"/>
                                    </div>
                                    </div>
                            </div>
                                                                                            
                            <div className="row">
                                <div className="col-md-6 pr-1">
                                    <div className="form-group">
                                        <label>Student Email</label>
                                        <input type="email" className="form-control" placeholder="Student Email" value="ÄBC"/>
                                    </div>
                                </div>
                                <div className="col-md-6 pl-1">
                                    <div className="form-group">
                                        <label>Parent Email</label>
                                        <input type="email" className="form-control" placeholder="Parent Email" value="ÄBC"/>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="row">
                                <div className="col-md-12">
                                    <div className="form-group">
                                        <label>Academic Session</label>
                                        <input type="text" className="form-control" placeholder="Academic Session" value="ÄBC"/>
                                    </div>
                                </div>
                            </div>
                                                                                            
                            <div className="row">
                                <div className="col-md-4 pr-1">
                                    <div className="form-group">
                                        <label>Username</label>
                                        <input type="text" className="form-control" placeholder="Username" value="ÄBC"/>
                                    </div>
                                </div>
                                <div className="col-md-4 px-1">
                                    <div className="form-group">
                                        <label>Date of Admission</label>
                                        <input type="text" className="form-control" placeholder="Date of Admission" value="ÄBC"/>
                                    </div>
                                </div>
                                <div className="col-md-4 pl-1">
                                    <div className="form-group">
                                        <label>Enabled</label>
                                        <input type="number" className="form-control" placeholder="ZIP Code" value="ÄBC"/>
                                    </div>
                                </div>
                            </div>

                            <div className="row">
                                <div className="col-md-12">
                                        <div className="form-group">
                                            <label>About Me</label>
                                            <textarea rows="4" cols="80" className="form-control" placeholder="Here can be your description" value="ÄBC">Lamborghini Mercy, Your chick she so thirsty, I'm in that two seat Lambo.</textarea>
                                        </div>
                                </div>
                            </div>
                            <button type="submit" className="btn btn-info btn-fill pull-right">Update Profile</button>
                                                                                            
                            <div className="clearfix"></div>
                       </form>
                </div>
            </div>
        </div>
                                                                            
    </div>
</div>
</div>




        </div>  
        </div>  
        );  
        }  
        }  

        export default EditStudent;