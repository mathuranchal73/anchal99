import React, { Component } from 'react';
import { FaPlus } from 'react-icons/fa';

class BulkUploadStudents extends Component {
   

    render() {
        return (
          <div
            className={
              'card textcenter mt-3 ' +
              (this.props.formDisplay ? '' : 'add-appointment')
            }
          >
              <div
                className="apt-addheading card-header bg-primary text-white">
                <FaPlus /> Bulk Upload Students
              </div>
    
            


            <div className="card-body">
              <form id="bulkUploadForm" noValidate onSubmit={this.handleAdd}> 

                <div className="form-group form-row">
                
                  <div className="col-md-4">
                    <input type="file" className="btn-primary d-block ml-auto"/>  
                  </div>
          
                  <div className="offset-md-2 col-md-10">
                  <button  type="submit" className="btn btn-primary d-block ml-auto">Upload File</button>
                  </div>
                
                </div>  
                  
              </form>
            </div>
          </div>
        );
      }
    }


export default BulkUploadStudents;
