package com.sms.emailservice.service;

import org.springframework.mail.SimpleMailMessage;

import freemarker.template.TemplateException;

public interface EmailService {
	
	 void sendSimpleMessage(String to,
             String subject,
             String text);
	 
	 void sendMessageWithAttachment(String to,
             String subject,
             String text,
             String pathToAttachment);

	void sendSimpleMessageUsingTemplate(String to, String subject, String text) throws TemplateException;

}
