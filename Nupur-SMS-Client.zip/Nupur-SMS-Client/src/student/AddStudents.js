import React, { Component } from 'react';
import { FaPlus } from 'react-icons/fa';

class AddStudents extends Component {
    constructor() {
        super();
        this.state = {
          firstName: '',
          lastName: '',
          studentEmail: '',
          parentEmail: '',
          doa: ''
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleAdd = this.handleAdd.bind(this);
      }


      handleAdd(e) {
        e.preventDefault();
        let tempStudents = {
            firstName: this.state.firstName,
            lastName: this.state.lastName,
            studentEmail: this.state.studentEmail,
            parentEmail: this.state.parentEmail,
            doa: this.state.doa 
        };

        this.props.addStudents(tempStudents);

    this.setState({
        firstName: '',
        lastName: '',
        studentEmail: '',
        parentEmail: '',
        doa: ''
    });
    this.props.toggleForm();
  }


  handleChange(e) {
    const target = e.target;
    const value = target.value;
    const name = target.name;

    this.setState({
      [name]: value
    });
  }


  render() {
    return (
      <div
        className={
          'card textcenter mt-3 ' +
          (this.props.formDisplay ? '' : 'add-appointment')
        }
      >
        <div
          className="apt-addheading card-header bg-primary text-white"
          onClick={this.props.toggleForm}
        >
          <FaPlus /> Add Student
        </div>

        <div className="card-body">
          <form id="aptForm" noValidate onSubmit={this.handleAdd}>
            <div className="form-group form-row">
              <label
                className="col-md-2 col-form-label text-md-right"
                htmlFor="firstName"
                readOnly
              >
                First Name
              </label>
              <div className="col-md-10">
                <input
                  type="text"
                  className="form-control"
                  name="firstName"
                  placeholder="First Name"
                  value={this.state.firstName}
                  onChange={this.handleChange}
                />
              </div>
            </div>

            <div className="form-group form-row">
              <label
                className="col-md-2 col-form-label text-md-right"
                htmlFor="lastName"
              >
                Last Name
              </label>
              <div className="col-md-10">
                <input
                  type="text"
                  className="form-control"
                  name="lastName"
                  placeholder="Last Name"
                  value={this.state.lastName}
                  onChange={this.handleChange}
                />
              </div>
            </div>
            <div className="form-group form-row">
              <label
                className="col-md-2 col-form-label text-md-right"
                htmlFor="studentEmail"
              >
                Student Email
              </label>
              <div className="col-md-10">
                <input
                  type="email"
                  className="form-control"
                  name="studentEmail"
                  placeholder="Student Email"
                  value={this.state.studentEmail}
                  onChange={this.handleChange}
                />
              </div>
            </div>
            <div className="form-group form-row">
              <label
                className="col-md-2 col-form-label text-md-right"
                htmlFor="studentEmail"
              >
                Parent's Email
              </label>
              <div className="col-md-10">
                <input
                  type="email"
                  className="form-control"
                  name="parentEmail"
                  placeholder="Parent Email"
                  value={this.state.parenttEmail}
                  onChange={this.handleChange}
                />
              </div>
            </div>


            <div className="form-group form-row">
              <label
                className="col-md-2 col-form-label text-md-right"
                htmlFor="aptDate"
              >
                Date
              </label>
              <div className="col-md-4">
                <input
                  type="date"
                  className="form-control"
                  name="doa"
                  id="doa"
                  value={this.state.doa}
                  onChange={this.handleChange}
                />
              </div>
              <div className="form-group form-row">
                  <label className="col-md-2 text-md-right" htmlFor="aptNotes">
                    Bulk
                  </label>
                 <input type="file" className="form-control"  id="aptNotes"
                  placeholder="Appointment Notes"
                  value={this.state.aptNotes}
                  onChange={this.handleChange} />
               </div>
              
            </div>

           
    

            <div className="form-group form-row mb-0">
              <div className="offset-md-2 col-md-10">
                <button
                  type="submit"
                  className="btn btn-primary d-block ml-auto"
                >
                  Add Student
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    );
  }
}

export default AddStudents;
