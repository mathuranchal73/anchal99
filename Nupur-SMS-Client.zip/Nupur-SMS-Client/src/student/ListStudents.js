import React, { Component } from 'react';
import { FaTimes } from 'react-icons/fa';
import Moment from 'react-moment';

class ListStudents extends Component {
    render() {
        return (
          <div className="appointment-list item-list mb-3">
            {this.props.students.map(item => (
              <div className="pet-item col media py-3" key={item.id}>
                <div className="mr-3">
                  <button
                    className="pet-delete btn btn-sm btn-danger"
                    onClick={() => this.props.deleteStudent(item)}
                  >
                    <FaTimes />
                  </button>
                </div>
    
                <div className="pet-info media-body">
                  <div className="pet-head d-flex">
                    <span
                      className="pet-name"
                      contentEditable
                      suppressContentEditableWarning
                      onBlur={e =>
                        this.props.updateInfo(
                          'firstName',
                          e.target.innerText,
                          item.id
                        )
                      }
                    >
                      {item.id}--{item.firstName}
                    </span>
                    <span className="apt-date ml-auto">
                      <Moment
                        date={item.doa}
                        parse="YYYY-MM-dd hh:mm"
                        format="MMM-d h:mma"
                      />
                    </span>
                  </div>
    
                  <div className="owner-name">
                    <span className="label-item">First Name: </span>
                    <span
                      contentEditable
                      suppressContentEditableWarning
                      onBlur={e =>
                        this.props.updateInfo(
                          'firstName',
                          e.target.innerText,
                          item.id
                        )
                      }
                    >
                      {item.firstName}
                    </span>
                  </div>
                  <div className="owner-name">
                    <span className="label-item">Last Name: </span>
                    <span
                      contentEditable
                      suppressContentEditableWarning
                      onBlur={e =>
                        this.props.updateInfo(
                          'lastName',
                          e.target.innerText,
                          item.id
                        )
                      }
                    >
                      {item.lastName}
                    </span>
                  </div>
                  <div
                    className="apt-notes"
                    contentEditable
                    suppressContentEditableWarning
                    onBlur={e =>
                      this.props.updateInfo(
                        'aptNotes',
                        e.target.innerText,
                        item.aptId
                      )
                    }
                  >
                    {item.aptNotes}
                  </div>
                </div>
              </div>
            ))}
          </div>
        );
      }
    }
    
    export default ListStudents;
    