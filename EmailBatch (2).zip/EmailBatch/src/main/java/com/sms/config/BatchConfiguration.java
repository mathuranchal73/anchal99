package com.sms.config;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.kafka.support.KafkaHeaders;

import com.sms.kafka.Receiver;
import com.sms.model.MailObject;
import com.sms.processor.JobCompletionNotificationListener;
import com.sms.processor.MailItemProcessor;

@Configuration
@EnableBatchProcessing
@Service
public class BatchConfiguration {
	
 private static final Logger LOGGER = LoggerFactory.getLogger(BatchConfiguration.class);
	 

	  	  

	@Autowired
	public JobBuilderFactory jobBuilderFactory;
	
    @Autowired
    public StepBuilderFactory stepBuilderFactory;
    
    @Bean
    public FlatFileItemReader<MailObject> reader() {
        return new FlatFileItemReaderBuilder<MailObject>()
            .name("mailItemReader")
            .resource(new ClassPathResource("sample-data.csv"))
            .delimited()
            .names(new String[]{"toemail", "subject","text"})
            .fieldSetMapper(new BeanWrapperFieldSetMapper<MailObject>() {{
                setTargetType(MailObject.class);
            }})
            .build();
    }
    
    
    @Autowired
    public MailItemProcessor processor;
    
    @Bean
    public JdbcBatchItemWriter<MailObject> writer(DataSource dataSource) {
        return new JdbcBatchItemWriterBuilder<MailObject>()
            .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
            .sql("INSERT INTO mail (toemail, subject, text) VALUES (:toemail, :subject, :text)")
            .dataSource(dataSource)
            .build();
    }
    // end::readerwriterprocessor[]
    
    
 // tag::jobstep[]
  @Bean
    public Job importUserJob(JobCompletionNotificationListener listener, Step step1) {
        return jobBuilderFactory.get("importUserJob")
            .incrementer(new RunIdIncrementer())
            .listener(listener)
            .flow(step1)
            .end()
            .build();
    }
    
   /** @Bean
    public Step step1(JdbcBatchItemWriter<MailObject> writer) {
        return stepBuilderFactory.get("step1")
            .<MailObject, MailObject> chunk(10)
            .reader(reader())
            .processor(processor())
            .writer(writer)
            .build();
    }**/
    // end::jobstep[]
    
    
    
    @Bean
    @KafkaListener(id = "${kafka.group-id}",topics = "${kafka.topic-name}")
    public Step step1(List<String> data,
  	      @Header(KafkaHeaders.RECEIVED_PARTITION_ID) List<Integer> partitions,
  	      @Header(KafkaHeaders.OFFSET) List<Long> offsets) {
    	 LOGGER.info("start of batch receive");
    	 
    	 ArrayList<String> arr= new ArrayList<>();
 	    for (int i = 0; i < data.size(); i++) {
 	    	try {
				processor.process(data.get(i));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
 	      LOGGER.info("received message='{}' with partition-offset='{}'", data.get(i),
 	          partitions.get(i) + "-" + offsets.get(i));
 	      
 	      arr.add(data.get(i));
 	    }
 	     
 	    LOGGER.info("end of batch receive");
 	    
 	   return stepBuilderFactory.get("step1")
 	            .<MailObject, MailObject> chunk(10)
 	            .reader(reader())
 	            .build();
    }
    
}
