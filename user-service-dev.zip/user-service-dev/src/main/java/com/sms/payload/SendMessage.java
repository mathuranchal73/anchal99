package com.sms.payload;

public class SendMessage {
	
	
	private String toemail;	
	
	private Long user_id;

	public String getToemail() {
		return toemail;
	}

	public void setToemail(String toemail) {
		this.toemail = toemail;
	}

	public Long getUser_id() {
		return user_id;
	}

	public void setUser_id(Long user_id) {
		this.user_id = user_id;
	}
	
    

}
